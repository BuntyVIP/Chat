# ChatGum App
A real time chatting application with rooms developed using websockets using Node.js, Express and Socket.io with Vanilla JS on the front-end with a custom UI.
